package felini.melhorpreco;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends ActionBarActivity implements View.OnClickListener {

  EditText oEditPrimeiroProduto;
  EditText oEditValorPrimeiroProduto;
  EditText oEditSegundoProduto;
  EditText oEditValorSegundoProduto;
  Button oBtnCalcular;
  Button oBtnLimpar;

  @Override
  protected void onCreate (Bundle savedInstanceState) {

    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    oEditPrimeiroProduto      = (EditText)findViewById(R.id.editPrimeiroProduto);
    oEditValorPrimeiroProduto = (EditText)findViewById(R.id.editValorPrimeiroProduto);
    oEditSegundoProduto       = (EditText)findViewById(R.id.editSegundoProduto);
    oEditValorSegundoProduto  = (EditText)findViewById(R.id.editValorSegundoProduto);

    oBtnCalcular = (Button)findViewById(R.id.btnCalcular);
    oBtnCalcular.setOnClickListener(this);

    oBtnLimpar = (Button)findViewById(R.id.btnLimpar);
    oBtnLimpar.setOnClickListener(this);

  }

  /**
   * Verifica qual o produto possui o valor mais barato
   * @return String
   */
  private String calcular() {

    int iGramasPrimeiroProduto = Integer.parseInt(oEditPrimeiroProduto.getText().toString());
    float nValorPrimeiroProduto = Float.parseFloat(oEditValorPrimeiroProduto.getText().toString());

    int iGramasSegundoProduto = Integer.parseInt(oEditSegundoProduto.getText().toString());
    float nValorSegundoProduto = Float.parseFloat(oEditValorSegundoProduto.getText().toString());

    float nCalculoProduto1 = (nValorPrimeiroProduto/iGramasPrimeiroProduto);
    float nCalculoProduto2 = (nValorSegundoProduto/iGramasSegundoProduto);

    String sRetorno = getString(R.string.msg_produto_iguais);
    String sProduto = null;
    if (nCalculoProduto1 > nCalculoProduto2) {

      float nMultiplica = (nCalculoProduto2*iGramasPrimeiroProduto);
      sProduto = getString(R.string.msg_produto_segundo);
      if (nMultiplica >= nValorPrimeiroProduto) {
        sProduto = getString(R.string.msg_produto_primeiro);
      }

      sRetorno = getString(R.string.msg_produto_barato, sProduto);

    } else if (nCalculoProduto2 > nCalculoProduto1) {

      sProduto = getString(R.string.msg_produto_primeiro);
      float nMultiplica = (nCalculoProduto1*iGramasSegundoProduto);
      if (nMultiplica >= nValorSegundoProduto) {
        sProduto = getString(R.string.msg_produto_segundo);
      }
      sRetorno = getString(R.string.msg_produto_barato, sProduto);
    }
    return sRetorno;
  }

  public void onClick (View oView) {

    switch (oView.getId()) {

      case R.id.btnCalcular:

        try {

          this.validar();
          String sRetorno = this.calcular();
          Toast.makeText(this, sRetorno, Toast.LENGTH_LONG).show();

        } catch (Exception oException) {
          Toast.makeText(this, oException.getMessage(), Toast.LENGTH_LONG).show();
        }

        break;

      case R.id.btnLimpar:

        oEditPrimeiroProduto.setText("");
        oEditValorPrimeiroProduto.setText("");
        oEditSegundoProduto.setText("");
        oEditValorSegundoProduto.setText("");
        break;
    }
  }

  /**
   * Valida as informações passadas na tela antes de processar com o cálculo
   * @throws Exception
   */
  private void validar() throws Exception {

    String sPrimeiroProduto      = oEditPrimeiroProduto.getText().toString().trim();
    String sValorPrimeiroProduto = oEditValorPrimeiroProduto.getText().toString().trim();
    String sSegundoProduto       = oEditSegundoProduto.getText().toString().trim();
    String sValorSegundoProduto  = oEditValorSegundoProduto.getText().toString().trim();

    if (sPrimeiroProduto.length() == 0) {
      throw new Exception(getString(R.string.erro_gramas_primeiro_produto));
    }

    if (sValorPrimeiroProduto.length() == 0) {
      throw new Exception(getString(R.string.erro_valor_primeiro_produto));
    }

    if (sSegundoProduto.length() == 0) {
      throw new Exception(getString(R.string.erro_gramas_segundo_produto));
    }

    if (sValorSegundoProduto.length() == 0) {
      throw new Exception(getString(R.string.erro_valor_segundo_produto));
    }
  }


  @Override
  public boolean onCreateOptionsMenu (Menu menu) {
    // Inflate the menu; this adds items to the action bar if it is present.
    getMenuInflater().inflate(R.menu.menu_main, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected (MenuItem item) {

    switch (item.getItemId()) {

      case R.id.action_sair:

        finish();
        break;

      case R.id.action_sobre:

        Intent oIntentSobre = new Intent(this, SobreActivity.class);
        startActivity(oIntentSobre);
        break;

      default:
        Toast.makeText(this, getString(R.string.opcao_nao_encontrada), Toast.LENGTH_SHORT).show();

    }
    return super.onOptionsItemSelected(item);
  }
}
